package pos;

import java.util.*;

/**
 * Singleton: one BillManager per application run.
 * Holds all generated bills and the bill-number counter.
 */
public class BillManager {

    // ── Category membership lists (used by Bill for totals) ──────────────────
    public static final List<String> COSMETICS   = List.of(
            "Bath Soap", "Face Cream", "Face Wash", "Hair Spray", "Hair Gell", "Body Loshan");
    public static final List<String> GROCERY     = List.of(
            "Rice", "Food Oil", "Daal", "Wheat", "Sugar", "Tea");
    public static final List<String> COLD_DRINKS = List.of(
            "Maza", "Coca Cola", "Frooti", "Thumbs Up", "Limca", "Sprite");

    // ── Prices (Rs.) ──────────────────────────────────────────────────────────
    public static final Map<String, Double> PRICES;
    static {
        Map<String, Double> m = new LinkedHashMap<>();
        m.put("Bath Soap",  60.0);  m.put("Face Cream",  120.0);
        m.put("Face Wash",  60.0);  m.put("Hair Spray",  200.0);
        m.put("Hair Gell",  140.0); m.put("Body Loshan", 100.0);
        m.put("Rice",       40.0);  m.put("Food Oil",    120.0);
        m.put("Daal",       60.0);  m.put("Wheat",       180.0);
        m.put("Sugar",      50.0);  m.put("Tea",         100.0);
        m.put("Maza",       30.0);  m.put("Coca Cola",   60.0);
        m.put("Frooti",     50.0);  m.put("Thumbs Up",   40.0);
        m.put("Limca",      40.0);  m.put("Sprite",      40.0);
        PRICES = Collections.unmodifiableMap(m);
    }

    // ── Tax rates ─────────────────────────────────────────────────────────────
    public static final double COSMETIC_TAX_RATE   = 0.05;
    public static final double GROCERY_TAX_RATE    = 0.10;
    public static final double COLD_DRINK_TAX_RATE = 0.05;

    // ── Singleton ──────────────────────────────────────────────────────────────
    private static BillManager instance;
    private BillManager() {}
    public static synchronized BillManager getInstance() {
        if (instance == null) instance = new BillManager();
        return instance;
    }

    // ── State ──────────────────────────────────────────────────────────────────
    private final Map<Integer, Bill> bills = new LinkedHashMap<>();
    private int nextBillNumber = 4000 + (int)(Math.random() * 100);

    public int getNextBillNumber() { return nextBillNumber; }

    public Bill generateBill(String customerName, String phone, List<Product> products) {
        List<Product> purchased = products.stream()
                .filter(p -> p.getQuantity() > 0).toList();

        double cosTotal  = purchased.stream().filter(p -> COSMETICS.contains(p.getName()))
                .mapToDouble(Product::getTotal).sum();
        double groTotal  = purchased.stream().filter(p -> GROCERY.contains(p.getName()))
                .mapToDouble(Product::getTotal).sum();
        double cdTotal   = purchased.stream().filter(p -> COLD_DRINKS.contains(p.getName()))
                .mapToDouble(Product::getTotal).sum();

        double cosTax = cosTotal  * COSMETIC_TAX_RATE;
        double groTax = groTotal  * GROCERY_TAX_RATE;
        double cdTax  = cdTotal   * COLD_DRINK_TAX_RATE;

        Bill bill = new Bill(nextBillNumber++, customerName, phone,
                             purchased, cosTax, groTax, cdTax);
        bills.put(bill.getBillNumber(), bill);
        return bill;
    }

    public Optional<Bill> findBill(int billNumber) {
        return Optional.ofNullable(bills.get(billNumber));
    }
}
